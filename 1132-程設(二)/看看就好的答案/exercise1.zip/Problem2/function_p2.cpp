#include <iostream>
#include "header_p2.h"

using namespace std;

void student::Takedata(){
    cout << "In Takedata()" << endl;
    cout << "Enter studentID:";
    cin >> studentID;
    cout << "Enter student name:";
    cin >> name;
    cout << "Enter grades in English, Math, and Physics:"; 
    cin >> eng >> math >> phy;
    avg_grade = avg();
}

float student::avg(){
    return (eng+math+phy)/3;
}

void student::Showdata(){
    cout << "In Showdata()" << endl
         << "StudentID:" << studentID << endl
         << "Student name:" << name << endl
         << "English:" << eng << endl
         << "Math:" << math << endl
         << "Physics:" << phy << endl;
}

void student::PassOrFail(){
    if(avg_grade >= 60){
        cout << "Pass";
    }else{
        cout << "Fail";
    }
}