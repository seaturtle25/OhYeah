#ifndef _HEADER_P2_H_
#define _HEADER_P2_H_

class student{
private:
    int studentID;
    char name[20];
    float eng, math, phy, avg_grade;
    float avg();
public:
    void Takedata();
    void Showdata();
    void PassOrFail();
};


#endif