#include <iostream>
#include "header_p4.h"

using namespace std;

void CompanyA::printMessage(){
    cout << "Welcome to Company A!" << endl;
}

void CompanyB::printMessage(){
    cout << "Welcome to Company B!" << endl;
}