/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>
#include "header_p4.h"

using namespace std;

int main()
{
    string enter;
    
    cin >> enter;
    if(enter == "A"){
        CompanyA::printMessage();
    }else if(enter == "B"){
        CompanyB::printMessage();
    }

    return 0;
}