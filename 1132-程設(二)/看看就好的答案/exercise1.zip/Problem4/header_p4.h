#ifndef _HEADER_P4_H_
#define _HEADER_P4_H_

namespace CompanyA{
    void printMessage();
};

namespace CompanyB{
    void printMessage();
}

#endif