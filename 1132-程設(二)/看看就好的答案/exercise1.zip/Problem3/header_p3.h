#ifndef _HEADER_P3_
#define _HEADER_P3_

class BankAccount{
private:
    double balance;
public:
    BankAccount(double);
    void deposit(double);
    void withdraw(double);
    double getBalance();
};

#endif