/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include "header_p3.h"

using namespace std;

int main()
{
    double initialBalance, depositAmount, WithdrawAmount;
    
    cout << "Enter initial balance: ";
    cin >> initialBalance;
    cout << "Enter deposit amount: ";
    cin >> depositAmount;
    cout << "Enter withdrawal amount: ";
    cin >> WithdrawAmount;
    
    BankAccount test(initialBalance);
    test.deposit(depositAmount);
    test.withdraw(WithdrawAmount);
    cout << "Current Balance: $" << test.getBalance() << endl;

    return 0;
}