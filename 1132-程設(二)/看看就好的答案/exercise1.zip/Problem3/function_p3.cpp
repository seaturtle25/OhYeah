#include <iostream>
#include "header_p3.h"

using namespace std;

BankAccount::BankAccount(double bal){
    cout << "Initial balance: $" << bal << endl;
    balance = bal;
}

void BankAccount::deposit(double amount){
    cout << "Depositing $" << amount << "..." << endl;
    balance += amount;
}

void BankAccount::withdraw(double amount){
    cout << "Withdrawing $" << amount << "..." << endl;
    if(amount < balance) balance -= amount;
}

double BankAccount::getBalance(){
    return balance;
}