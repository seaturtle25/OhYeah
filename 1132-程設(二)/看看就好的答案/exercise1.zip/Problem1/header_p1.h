#ifndef _HEADER_P1_H_
#define _HEADER_P1_H_

class BOOK{
private:
    int BOOK_NO;
    char TITLE[20];
    float PRICE;
    float TOTAL_COST;
public:
    void INPUT();
    void PURCHASE();
};

#endif // E01_HEADER_H_