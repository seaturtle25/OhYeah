#include<iostream>
#include"header_p1.h"

using namespace std;

void BOOK::INPUT(){
    cout << "In INPUT()" << endl;
    cout << "Enter Book Title:";
    cin >> TITLE;
    //cout << TITLE << endl;
    cout << "Enter Book Number:";
    cin >> BOOK_NO;
    //cout << BOOK_NO << endl;
    cout << "Enter price per copy:";
    cin >> PRICE;
    //cout << PRICE << endl;
}

void BOOK::PURCHASE(){
    int number;
    cout << "In PURCHASE():" << endl;
    cout << "Enter number of copies to purchase:";
    cin >> number;
    cout << "Total cost:" << number*PRICE << endl;
}
