#include <iostream>

using namespace std;

class rectangle{
private:
    int width, height;
public:
    rectangle(int w, int h): width(w), height(h){}
    rectangle(): width(0), height(0){}
    rectangle operator+(const rectangle& r){
        rectangle tmp;
        if(height == r.height){
            tmp.height = height;
            tmp.width = width + r.width;
        }else if(width == r.width){
            tmp.width = width;
            tmp.height = height + r.height;
        }else if((width != r.width) && (height != height)){
            if(height >= r.height){
                tmp.height = height;
            }else{
                tmp.height = r.height;
            }
            if(width >= r.width){
                tmp.width = width;
            }else{
                tmp.width = r.width;
            }
        }
        return tmp;
    }
    void operator=(const rectangle& r){
        width = r.width;
        height = r.height;
    }
    friend ostream& operator<<(ostream& os, const rectangle& r);
};
ostream& operator<<(ostream& os, const rectangle& r){
    for(int i=0; i<r.height; i++){
        for(int j=0; j<r.width; j++){
            os << "* ";
        }
        os << endl;
    }
    return os;
}

int main(){
    int w1, h1, w2, h2;
    cin >> w1 >> h1 >> w2 >> h2;
    rectangle r1(w1, h1), r2(w2, h2), r;
    r = r1+r2;
    cout << r;
    return 0;
}

