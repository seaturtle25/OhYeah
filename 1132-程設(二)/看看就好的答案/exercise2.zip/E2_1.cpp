#include <iostream>
#include <string>
#include <vector>

using namespace std;

template<class T>
class node{
public:
    T v;
    node<T> *next;
    node(T x){ v=x; next=nullptr; }
};

template<class T>
class queue{
    node<T> *start;
    node<T> *end;
public:
    queue(): start(nullptr), end(nullptr){}
    bool empty(){
        if(start==nullptr && end==nullptr){
            return true;
        }else{
            return false;
        }
    }
    //enqueue non repeated elements
    void safe_push(T v){
        if(start == nullptr){
            node<T>* new_node = new node<T>(v);
            start = end = new_node;
        }else{
            node<T> *check = start;
            while(v != check->v){
                if(check != end){
                    check = check->next;
                }else if(check == end){
                    node<T>* new_node = new node<T>(v);
                    end->next = new_node;
                    end = new_node;
                }
            }
        }
    }

    T front(){ return start->v; }
    void pop(){
        if(start!=nullptr){
            node<T> *tmp = start;
            start = start->next;
            delete tmp;
            if(start == nullptr) end=nullptr;
        }
    }
};

int main(){
    queue<string> q;
    string s1, s2, s3, s4;
    cin >> s1 >> s2 >> s3 >> s4;
    q.safe_push(s1);
    q.safe_push(s2);
    q.safe_push(s3);
    q.safe_push(s4);
    q.pop();
    while(!q.empty()){
        cout << q.front() << ' ';
        q.pop();
    }
    return 0;
}
